<?php

echo "<h1>Etusivu</h1><br>";
echo "Tämä on etelän hetelmän verkkokauppa ja täältä saa ostettua minkälaista hetelmää vain immeinen haluaa."

?>