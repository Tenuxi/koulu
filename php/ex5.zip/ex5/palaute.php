

<form class="form-style-4" id="form" name="form" method="post" action="index.php?page=kasittelija"> 

<label for="nimi">Nimi:</label><br />
<input type="text" name="nimi" id="nimi" /> <br />

<label for="sposti">Sähköposti:</label><br />
<input type="text" name="sposti" id="sposti" /> <br />

<label for="viesti">Viesti:</label><br />
<textarea name="viesti" id="viesti" cols="45" rows="5"></textarea> <br />

<input type="submit" name="laheta" id="laheta" value="Lähetä palaute" />
</form>

